DROP TABLE IF EXISTS INSURANCE;

CREATE TABLE INSURANCE (
insurance_number INT AUTO_INCREMENT PRIMARY KEY,
customer_id INT NOT NULL,
insurance_type VARCHAR(50) NOT NULL,
insurance_amount INT NOT NULL,
insurance_end_date DATE DEFAULT CURDATE() + 1
);
 

INSERT INTO INSURANCE (customer_id, insurance_type, insurance_amount, insurance_end_date)
VALUES (1, 'HEALTH INSURANCE', 1000000, CURDATE()+1000);

INSERT INTO INSURANCE (customer_id, insurance_type, insurance_amount, insurance_end_date)
VALUES (1, 'LIFE INSURANCE', 1500000, CURDATE()+1000);

INSERT INTO INSURANCE (customer_id, insurance_type, insurance_amount, insurance_end_date)
VALUES (2, 'CAR INSURANCE', 120000, CURDATE()+1000);

INSERT INTO INSURANCE (customer_id, insurance_type, insurance_amount, insurance_end_date)
VALUES (3, 'BIKE INSURANCE', 80000, CURDATE()+1000);